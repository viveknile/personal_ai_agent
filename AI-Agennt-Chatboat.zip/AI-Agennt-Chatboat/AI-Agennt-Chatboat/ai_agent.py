# ================================
# Load environment variables
# ================================
from dotenv import load_dotenv
import os

load_dotenv()

GROQ_API_KEY = os.environ.get("GROQ_API_KEY")
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY")

if not GROQ_API_KEY:
    raise RuntimeError("❌ GROQ_API_KEY not found")

if not TAVILY_API_KEY:
    raise RuntimeError("❌ TAVILY_API_KEY not found")

# ================================
# Imports
# ================================
from langchain_groq import ChatGroq
from langchain_tavily import TavilySearch
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage

# ================================
# Tool
# ================================
search_tool = TavilySearch(max_results=2)

# ================================
# Agent Logic
# ================================
def get_response_from_ai_agent(
    llm_id: str,
    query,
    allow_search: bool,
    system_prompt: str,
    provider: str
):

    if provider != "Groq":
        raise ValueError("Only Groq is supported in this version.")

    llm = ChatGroq(
        model=llm_id,
        api_key=GROQ_API_KEY
    )

    tools = [search_tool] if allow_search else []

    agent = create_react_agent(
        model=llm,
        tools=tools
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": str(query)}
    ]

    response = agent.invoke({"messages": messages})

    for msg in reversed(response["messages"]):
        if isinstance(msg, AIMessage):
            return msg.content

    return "No response generated."
